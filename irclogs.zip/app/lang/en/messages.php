<?php return array(

	'join'    => ':username joined the room',
	'quit'    => ':username left the room',
	'part'    => ':username left the room',
	'message' => '<span class="log-entry-username">:username</span> : :message',

);
